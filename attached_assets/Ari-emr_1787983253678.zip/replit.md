# ARI EMR (formerly SynaptiFlow, briefly Meridian)

## Overview

ARI is a modern hospital/clinic EMR-EHR platform, Epic-inspired but with a contemporary design. It combines full clinical workflows (patient charts, scheduling, encounters, orders, vitals) with the original SynaptiFlow AI medical imaging capabilities (DICOM viewing, AI diagnostics, 3D reconstruction). Planned modules: notes + diagnostics AI ("Ari"), billing/revenue cycle, CRM, and reporting/analytics.

## Recent Updates (July 27, 2026)

- **EMR foundation & redesign (Task #1)**: rebranded (now ARI); new design system (clinical ink-blue/teal palette, Inter + JetBrains Mono, `.emr-card` surfaces); EMR-style sidebar with Clinical / Imaging / Practice / Administration sections
- **Clinical database**: 7 new PostgreSQL tables — encounters, problems, medications, allergies, vitals, orders, appointments (see `shared/schema.ts`); patients moved from in-memory to Postgres with fixed ids p1–p20 so imaging studies stay linked
- **Seed data**: `server/seed-emr.ts` runs idempotently on startup (20 patients, problems/meds/allergies, encounters, vitals, orders, appointments across −3 to +7 days)
- **New pages**: Patients list (`/`), Epic-style patient chart (`/chart/:id` — demographics banner, allergy strip, vitals strip, Summary/Encounters/Orders & Results/Vitals/Imaging tabs), Schedule (`/appointments`, real API + create/check-in/cancel), provider day-at-a-glance Dashboard (`/dashboard`)
- Imaging viewer remains at `/patient/:id` (full-screen DICOM layout), linked from the chart

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- React 18 + TypeScript, Wouter routing, TanStack Query, Tailwind + shadcn/ui, Vite
- Design tokens in `client/src/index.css` (light + dark palettes, `--sidebar*`, chart colors, `.emr-*` utilities)
- Layout: dark sidebar (`components/layout/sidebar.tsx`) + header; imaging viewer routes render full-screen without sidebar

### Backend
- Express + TypeScript (ES modules), `tsx` dev runtime, port 5000, workflow `Start application` (`npm run dev`)
- **Two storage layers**: `server/emr-storage.ts` (Drizzle/Postgres — patients + clinical tables) and `server/storage.ts` MemStorage (imaging studies, AI analyses, reports, annotations)
- REST routes in `server/routes.ts`; clinical POST bodies validated with Zod insert schemas; timestamp fields coerced with `new Date()`
- Seeding wired in `server/index.ts` before server start (safe no-op if already seeded)

### Database
- Replit-managed PostgreSQL (Neon) via Drizzle ORM; `npm run db:push` to sync schema
- Appointments store date as `yyyy-MM-dd` text + `HH:mm` time; encounters/vitals/orders use timestamps
- Audit tables (audit_logs, security_events, etc.) power the HIPAA compliance dashboard

### AI & Imaging (from SynaptiFlow)
- AI medical assistant (`server/ai-medical-assistant.ts`) + floating chat widget — to be rebranded "Ari" in Task #2
- DICOM processing, 3D volume rendering (Three.js), MPR views, Radiology Hub, AI detection modules

## External Dependencies
- Radix UI/shadcn, Lucide icons, Inter + JetBrains Mono via Google Fonts, date-fns, recharts (available for reporting)
- Neon serverless Postgres, Drizzle ORM + Zod, connect-pg-simple sessions
