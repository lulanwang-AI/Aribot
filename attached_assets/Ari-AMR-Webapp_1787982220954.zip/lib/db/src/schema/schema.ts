import { z } from "zod";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export interface User {
  id: string;
  username: string;
  password: string;
  name: string;
  specialty: string;
  subspecialty: string;
  hospital: string;
  /** Ward or unit the clinician covers, shown on the stewardship worklist. */
  ward: string;
  city: string;
  state: string;
  /** Region id used to pick the default antibiogram for this user. */
  regionId: string;
  role: string;
  verified: boolean;
  phiSafeMode: boolean;
  bio: string;
  avatarUrl: string;
  credential: string;
  // Ari clinical-context fields. Optional so existing users aren't broken;
  // /api/ari/* gates access on these being set.
  email?: string;
  licenseType?: "MD" | "DO" | "NP" | "PA" | "RN" | "PharmD" | "OTHER";
  licenseNumber?: string;
  licenseState?: string;
  licenseVerifiedAt?: number | null;
  acceptedAriTermsAt?: number | null;
}

export const insertUserSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
  name: z.string().min(1),
  specialty: z.string().default(""),
  subspecialty: z.string().default(""),
  hospital: z.string().default(""),
  ward: z.string().default(""),
  city: z.string().default(""),
  state: z.string().default(""),
  regionId: z.string().default("us_northeast"),
  role: z.string().default("physician"),
  verified: z.boolean().default(false),
  phiSafeMode: z.boolean().default(true),
  bio: z.string().default(""),
  avatarUrl: z.string().default(""),
  credential: z.string().default("MD"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;

export const demoRequests = pgTable("demo_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  organization: text("organization").notNull(),
  role: text("role").notNull(),
  message: text("message").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDemoRequestSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  organization: z.string().min(1, "Organization is required"),
  role: z.string().min(1, "Role is required"),
  message: z.string().default(""),
});

export type InsertDemoRequest = z.infer<typeof insertDemoRequestSchema>;
export type DemoRequest = typeof demoRequests.$inferSelect;
