# Ari AMR - Project Overview

Ari AMR is an antimicrobial stewardship decision support tool for hospital
clinicians.
It answers two questions that sit at either end of an empiric course.

**Before cultures.**
Which antimicrobial agents to start, given the organisms this patient is actually likely to have
and the resistance pattern of the region the infection was acquired in.

**At 48 to 72 hours.**
Whether to stop, narrow, continue, escalate, or switch intravenous therapy to oral, given what the
laboratory has reported and how the patient has responded.

## Artifacts

- **`artifacts/aribots-web`** - Vite + React web app. The whole clinician-facing product.
- **`artifacts/api-server`** - Express API. Hosts the stewardship engine under `/api/amr/*` and the
  Ari chat surface under `/api/ari/*`.

The former community, telemedicine, news, groups, events, chat, training and clinical-documentation
surfaces have been removed, along with the Expo mobile app and its dedicated API that existed only
to serve them.

## The engine

`artifacts/api-server/src/amr/` is the heart of the product and is deliberately **deterministic**.
The same intake, against the same antibiogram and the same knowledge base version, returns the same
ranked regimens every time.
A stewardship committee has to be able to reconstruct and defend any recommendation the tool made,
which rules out free-form generation as the source of truth.

```
src/amr/
  types.ts              domain types, shared verbatim with the web app
  data/
    agents.ts           antimicrobial formulary: dosing, renal bands, monitoring, spectrum cost
    organisms.ts        organism catalogue, intrinsic resistance, definitive agents
    syndromes.ts        20 infection syndromes: differentials, regimens, durations, source control
    antibiogram.ts      16 regional resistance profiles, derived from a reference table
    risk-factors.ts     32 risk modifiers, mapped from the 14 screening questions
  engine/
    empiric.ts          differential, coverage arithmetic, ranking
    targeted.ts         the 48 to 72 hour decision
    dosing.ts           renal and weight-based dosing
    allergy.ts          beta-lactam side-chain cross-reactivity
  __tests__/
    engine.spec.ts      safety regression suite - run with `pnpm --filter @workspace/api-server run test:engine`
  store.ts              in-memory case store with seeded cases
  metrics.ts            stewardship programme metrics
  routes.ts             REST surface under /api/amr
```

### How a recommendation is reached

1. **Screening.**
   Fourteen questions, numbered on screen as the protocol numbers them.
   Between them they can fire 32 named risk modifiers.
2. **Applicable antibiogram.**
   A patient who fell ill while travelling carries the flora of where they were, so travel overrides
   residence.
   Returning from a high-resistance region within 90 days still shifts ESBL risk.
3. **Organism differential.**
   Syndrome baseline, bent by care setting, severity and the risk modifiers that fired, with
   diminishing returns so that many factors pointing one way raise an organism decisively without
   eliminating the rest.
4. **Coverage arithmetic.**
   For each candidate regimen, expected coverage is the sum over the bacterial differential of
   likelihood times the regional percent susceptible of the best agent in that regimen.
5. **Ranking.**
   The narrowest regimen that meets the coverage target wins.
   Targets are 85 percent for mild, 90 for moderate, 95 for severe and septic shock.
   Regimens within 2 points of the best available coverage count as equivalent, and breadth (the
   single broadest agent) is ranked before total spectrum cost.
6. **The 48 to 72 hour checkpoint.**
   Stop, narrow, continue, escalate, or switch to oral.

### Antibiogram provenance

The shipped regional profiles are **illustrative defaults, not surveillance data**, and the UI says
so on every screen that uses them.
A deploying facility replaces them with its own CLSI-interpreted antibiogram through
`registerAntibiogram`, after which every recommendation is driven by that facility's own isolates.

### Safety properties held by the test suite

`pnpm --filter @workspace/api-server run test:engine` asserts, among others:

- Severe and meningitic doses survive normal renal function.
- Paediatric patients get a refusal, not an adult dose.
- A contraindicated regimen is never marked as recommended.
- Risk-raised coverage flags unlock broader options but never suppress narrow ones.
- Anaerobic and atypical cover survives a culture that could never have grown them.
- A negative nares swab never withdraws therapy from a confirmed MRSA bloodstream infection.
- No bladder-only agent is chosen above the bladder.
- No stop while the patient is still neutropenic, or for culture-negative meningitis.
- A sterile-site isolate blocks the intravenous to oral switch.

## Ari chat

`/api/ari/*` is an adjunct, not the source of truth.
It explains a recommendation, retrieves the evidence behind it and answers follow-ups.
The regimen, dose, duration and monitoring plan come from the engine.
The chat needs `ANTHROPIC_API_KEY`; the engine does not, and the server boots and serves
recommendations without it.

Two modes: **verified** retrieves before stating a clinical fact and flags anything it could not
confirm, **rapid** answers from the model alone and labels itself as unverified.

## Running locally

```
pnpm install
pnpm run typecheck
PORT=8080 pnpm --filter @workspace/api-server run dev
PORT=20216 BASE_PATH=/ pnpm --filter @workspace/aribots-web run dev
```

The web dev server proxies `/api` to `http://localhost:8080`.
In the Replit deployment the platform router handles that before the request reaches Vite, so the
proxy is local-only.

## Two deployment shapes

The engine is pure computation over a versioned knowledge base and the case store is in memory, so
nothing about a recommendation needs a server.
That gives the product two shapes from one codebase.

**Served.**
`artifacts/api-server` hosts the engine at `/api/amr/*` and the Ari chat at `/api/ari/*`, and the web
app talks to it over HTTP.
This is the Replit deployment and the shape a facility runs.

**Standalone.**
Built with `VITE_STANDALONE=1`, the web app compiles the same engine source through the `@engine`
alias and runs it in the browser.
`src/lib/amrLocal.ts` stands in for the HTTP layer, held to the same `AmrApi` interface, so it is
the same engine rather than a reimplementation.
Routing switches to the hash because the result is a single document served from one URL.
The only capability that genuinely needs a server is the Ari chat, which requires a key that must
never reach a browser; it says so rather than failing when someone presses send.

```
python3 scripts/build_standalone.py out.html              # complete HTML document
ARTIFACT_MODE=1 python3 scripts/build_standalone.py out.html   # page content only, for an embedding host
```

The build inlines the JavaScript, CSS and images, leaving only the Google Fonts stylesheet external.
It comes out around 0.9 MB and needs no backend, no database and no key.

## Scope

Adult dosing only.
The engine holds no paediatric or neonatal doses and refuses to print one.
It is clinical decision support for licensed clinicians: it informs a prescribing decision, it does
not make one, and the prescriber remains responsible for the order.
