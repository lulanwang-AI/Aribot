import app, { initRoutes } from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

(async () => {
  await initRoutes();

  // The stewardship engine is deterministic and needs no model access. Only
  // the Ari chat surface uses the key, so its absence is logged, not fatal.
  logger.info(
    { configured: Boolean(process.env.ANTHROPIC_API_KEY) },
    "ANTHROPIC_API_KEY status (Ari chat only - stewardship engine is unaffected)",
  );

  app.listen(port, "0.0.0.0", () => {
    logger.info({ port }, "Server listening");
  });
})();
