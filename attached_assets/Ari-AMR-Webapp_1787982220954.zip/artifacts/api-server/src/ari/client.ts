import Anthropic from "@anthropic-ai/sdk";

/**
 * Lazily constructed Anthropic client.
 *
 * The stewardship engine is deterministic and does not call a model, so the
 * server must boot and serve recommendations whether or not a key is
 * configured. Only the Ari chat surface needs the key, and it asks for the
 * client at request time.
 */
let client: Anthropic | null = null;

export function isAriChatConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

export function getAnthropic(): Anthropic {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error(
      "ANTHROPIC_API_KEY is not configured. The Ari chat surface is unavailable; the stewardship engine is unaffected.",
    );
  }
  if (!client) {
    client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return client;
}

/**
 * Back-compat proxy so existing `anthropic.beta.messages.create(...)` call
 * sites keep working while construction stays lazy.
 */
export const anthropic = new Proxy({} as Anthropic, {
  get(_target, prop) {
    const instance = getAnthropic() as unknown as Record<string | symbol, unknown>;
    const value = instance[prop];
    return typeof value === "function" ? value.bind(instance) : value;
  },
});
