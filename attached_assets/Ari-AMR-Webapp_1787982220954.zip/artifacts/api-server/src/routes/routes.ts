import type { Express } from "express";
import type { Server } from "http";
import { z } from "zod";
import { insertDemoRequestSchema } from "@workspace/db";
import { storage } from "../storage";
import { computeMetrics } from "../amr/metrics";
import { hoursToReview, listCases } from "../amr/store";
import { ARI_GUEST_USER_ID } from "../ari/license";

const updateUserSchema = z.object({
  phiSafeMode: z.boolean().optional(),
  name: z.string().optional(),
  specialty: z.string().optional(),
  subspecialty: z.string().optional(),
  hospital: z.string().optional(),
  ward: z.string().optional(),
  regionId: z.string().optional(),
});

function sessionUserId(req: unknown): string {
  const r = req as { isAuthenticated?: () => boolean; user?: { id?: string } };
  if (typeof r.isAuthenticated === "function" && r.isAuthenticated() && r.user?.id) {
    return r.user.id;
  }
  return ARI_GUEST_USER_ID;
}

/**
 * Application routes outside the stewardship engine.
 *
 * The engine itself lives under /api/amr (see src/amr/routes.ts) and the Ari
 * chat surface under /api/ari. What remains here is identity, the worklist
 * notification counts the sidebar renders, and lead capture from the landing
 * page.
 */
export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.get("/api/me", async (req, res) => {
    const user = await storage.getUser(sessionUserId(req));
    if (!user) {
      res.status(404).json({ message: "User not found" });
      return;
    }
    const { password: _password, ...safe } = user;
    res.json(safe);
  });

  app.patch("/api/me", async (req, res) => {
    const parsed = updateUserSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: parsed.error.message });
      return;
    }
    const updated = await storage.updateUser(sessionUserId(req), parsed.data);
    if (!updated) {
      res.status(404).json({ message: "User not found" });
      return;
    }
    const { password: _password, ...safe } = updated;
    res.json(safe);
  });

  app.get("/api/users", async (_req, res) => {
    const users = await storage.getAllUsers();
    res.json(users.map(({ password: _password, ...safe }) => safe));
  });

  /**
   * Sidebar badge counts. These are the only numbers a stewardship clinician
   * needs to see before opening a screen: what is overdue, what needs a
   * decision, and what is actively unsafe.
   */
  app.get("/api/notifications", async (_req, res) => {
    const metrics = computeMetrics();
    const cases = listCases();
    res.json({
      reviewsDue: metrics.reviewsDue,
      reviewsOverdue: metrics.reviewsOverdue,
      alerts: metrics.coverageGapAlerts.filter((a) => a.severity === "high").length,
      activeCases: metrics.activeCases,
      nextReviewHours: cases
        .filter((c) => !c.targeted && !["completed", "stopped"].includes(c.status))
        .map(hoursToReview)
        .filter((hours) => hours > 0)
        .sort((a, b) => a - b)[0] ?? null,
    });
  });

  app.post("/api/demo-requests", async (req, res) => {
    const parsed = insertDemoRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: parsed.error.message });
      return;
    }
    const demoRequest = await storage.createDemoRequest(parsed.data);
    res.status(201).json(demoRequest);
  });

  return httpServer;
}
