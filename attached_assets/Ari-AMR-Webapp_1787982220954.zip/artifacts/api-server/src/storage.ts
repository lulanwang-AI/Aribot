import type { DemoRequest, InsertDemoRequest, InsertUser, User } from "@workspace/db";
import { randomUUID } from "crypto";

/**
 * User and demo-request storage.
 *
 * Stewardship cases live in `src/amr/store.ts`; this module only carries the
 * identity and lead-capture records the rest of the app needs. Both are in
 * memory so the app runs without a provisioned database.
 */
export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  createDemoRequest(request: InsertDemoRequest): Promise<DemoRequest>;
  getDemoRequests(): Promise<DemoRequest[]>;
}

const SEED_USERS: User[] = [
  {
    id: "u1",
    username: "cchea",
    password: "",
    name: "Dr. Chet Chea",
    specialty: "Infectious Disease",
    subspecialty: "Antimicrobial Stewardship",
    hospital: "Marin Health Medical Center",
    ward: "ICU and General Medicine",
    city: "Kentfield",
    state: "CA",
    regionId: "us_west",
    role: "physician",
    verified: true,
    phiSafeMode: true,
    bio: "Board-certified Infectious Disease specialist with 21 years of clinical experience. Expertise in HIV/AIDS, antimicrobial stewardship, and travel medicine.",
    avatarUrl: "",
    credential: "MD",
    email: "cchea@marinhealth.example",
    licenseType: "MD",
    licenseNumber: "CA-118422",
    licenseState: "CA",
    licenseVerifiedAt: Date.now(),
    acceptedAriTermsAt: Date.now(),
  },
  {
    id: "u2",
    username: "jlindqvist",
    password: "",
    name: "Jonas Lindqvist",
    specialty: "Pharmacy",
    subspecialty: "Infectious Diseases Pharmacy",
    hospital: "Marin Health Medical Center",
    ward: "Pharmacy",
    city: "Kentfield",
    state: "CA",
    regionId: "us_west",
    role: "pharmacist",
    verified: true,
    phiSafeMode: true,
    bio: "Runs the daily prospective audit and feedback round.",
    avatarUrl: "",
    credential: "PharmD",
    email: "jlindqvist@marinhealth.example",
    licenseType: "PharmD",
    licenseNumber: "CA-PH-9931",
    licenseState: "CA",
    licenseVerifiedAt: Date.now(),
    acceptedAriTermsAt: Date.now(),
  },
];

export class MemStorage implements IStorage {
  private users = new Map<string, User>(SEED_USERS.map((u) => [u.id, u]));
  private demoRequests: DemoRequest[] = [];

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return [...this.users.values()].find((u) => u.username === username);
  }

  async createUser(user: InsertUser): Promise<User> {
    const created = { ...user, id: randomUUID() } as User;
    this.users.set(created.id, created);
    return created;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const existing = this.users.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...data };
    this.users.set(id, updated);
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return [...this.users.values()];
  }

  async createDemoRequest(request: InsertDemoRequest): Promise<DemoRequest> {
    const created: DemoRequest = {
      id: randomUUID(),
      ...request,
      message: request.message ?? "",
      createdAt: new Date(),
    };
    this.demoRequests.push(created);
    return created;
  }

  async getDemoRequests(): Promise<DemoRequest[]> {
    return [...this.demoRequests];
  }
}

export const storage = new MemStorage();
