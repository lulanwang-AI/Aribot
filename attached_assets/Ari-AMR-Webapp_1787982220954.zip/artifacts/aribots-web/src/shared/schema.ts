import { z } from "zod";

export interface User {
  id: string;
  username: string;
  password: string;
  name: string;
  specialty: string;
  subspecialty: string;
  hospital: string;
  /** Ward or unit the clinician covers, shown on the stewardship worklist. */
  ward: string;
  city: string;
  state: string;
  /** Region id used to pick the default antibiogram for this user. */
  regionId: string;
  role: string;
  verified: boolean;
  phiSafeMode: boolean;
  bio: string;
  avatarUrl: string;
  credential: string;
  email?: string;
  licenseType?: "MD" | "DO" | "NP" | "PA" | "RN" | "PharmD" | "OTHER";
  licenseNumber?: string;
  licenseState?: string;
  licenseVerifiedAt?: number | null;
  acceptedAriTermsAt?: number | null;
}

export const insertUserSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
  name: z.string().min(1),
  specialty: z.string().default(""),
  subspecialty: z.string().default(""),
  interests: z.array(z.string()).default([]),
  hospital: z.string().default(""),
  city: z.string().default(""),
  state: z.string().default(""),
  role: z.string().default("physician"),
  verified: z.boolean().default(false),
  phiSafeMode: z.boolean().default(true),
  yearsExperience: z.number().default(0),
  rankingScore: z.number().default(50),
  badges: z.array(z.string()).default([]),
  bio: z.string().default(""),
  avatarUrl: z.string().default(""),
  credential: z.string().default("MD"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;

export interface TriagePost {
  id: string;
  authorId: string;
  title: string;
  content: string;
  tags: string[];
  likes: string[];
  images: string[];
  flagged: boolean;
  createdAt: string;
}

export const insertTriagePostSchema = z.object({
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  tags: z.array(z.string()).default([]),
  images: z.array(z.string()).default([]),
  noIdentifiersConfirmed: z.literal(true, {
    errorMap: () => ({ message: "You must confirm no patient identifiers" }),
  }),
});

export type InsertTriagePost = z.infer<typeof insertTriagePostSchema>;

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  content: string;
  parentId: string | null;
  anonymous: boolean;
  likes: string[];
  flagged: boolean;
  createdAt: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  abstract: string;
  researcherName: string;
  source: string;
  url: string;
  tags: string[];
  publishedAt: string;
  readingTime: number;
  likes: string[];
  commentCount: number;
}

export interface NewsComment {
  id: string;
  newsId: string;
  authorId: string;
  content: string;
  parentId: string | null;
  likes: string[];
  createdAt: string;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  topic: string;
  type: "hospital" | "interest";
  hospital: string;
  city: string;
  memberCount: number;
  members: string[];
}

export interface MedEvent {
  id: string;
  title: string;
  description: string;
  type: string;
  date: string;
  location: string;
  hostGroup: string;
  hostHospital: string;
  capacity: number;
  rsvps: string[];
  imageUrl: string;
  rsvpAvatars?: { id: string; name: string; avatarUrl: string }[];
}

export interface FlaggedItem {
  id: string;
  contentType: "post" | "comment";
  contentId: string;
  content: string;
  authorName: string;
  reason: string;
  reportedBy: string;
  status: "pending" | "safe" | "edit_requested" | "removed";
  createdAt: string;
}

export interface ChatThread {
  id: string;
  type: "direct" | "group";
  name: string;
  participants: string[];
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: number;
}

export interface ChatMessage {
  id: string;
  threadId: string;
  senderId: string;
  content: string;
  attachments: { name: string; type: string; url: string }[];
  createdAt: string;
}

export interface TrainingModule {
  id: string;
  title: string;
  description: string;
  outline: string[];
  duration: string;
  completedBy: string[];
}

export interface AribotHistory {
  id: string;
  title: string;
  tags: string[];
  folderId: string | null;
  createdAt: string;
}

export interface AribotFolder {
  id: string;
  name: string;
  createdAt: string;
}

export interface Team {
  id: string;
  name: string;
  description: string;
  members: {
    userId: string;
    role: "admin" | "member";
    name?: string;
    avatarUrl?: string;
    verified?: boolean;
    specialty?: string;
    hospital?: string;
    rankingScore?: number;
  }[];
}

export const insertCommentSchema = z.object({
  content: z.string().min(1, "Comment is required"),
  parentId: z.string().nullable().default(null),
  anonymous: z.boolean().default(false),
});

export const insertChatMessageSchema = z.object({
  content: z.string().min(1),
  attachments: z.array(z.object({
    name: z.string(),
    type: z.string(),
    url: z.string(),
  })).default([]),
});

export interface TelemedConsultation {
  id: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  chiefComplaint: string;
  symptoms: string[];
  urgency: "low" | "medium" | "high" | "urgent";
  status: "pending" | "accepted" | "in-progress" | "completed" | "cancelled";
  scheduledAt: string;
  createdAt: string;
  duration: number;
  earnings: number;
  doctorId: string | null;
  notes: string;
  diagnosis: string;
  prescriptions: string[];
  vitals: {
    bp?: string;
    heartRate?: number;
    temp?: string;
    spo2?: number;
    weight?: string;
  };
  insuranceProvider: string;
  paymentStatus: "pending" | "paid" | "processing";
  followUp: boolean;
  patientHistory: string;
  attachments: string[];
}

export interface TelemedEarnings {
  totalEarnings: number;
  thisMonth: number;
  thisWeek: number;
  pendingPayout: number;
  completedConsultations: number;
  avgPerConsultation: number;
}

export const insertDemoRequestSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  organization: z.string().min(1, "Organization is required"),
  role: z.string().min(1, "Role is required"),
  message: z.string().default(""),
});

export type InsertDemoRequest = z.infer<typeof insertDemoRequestSchema>;

export interface DemoRequest {
  id: string;
  name: string;
  email: string;
  organization: string;
  role: string;
  message: string | null;
  createdAt: Date;
}
