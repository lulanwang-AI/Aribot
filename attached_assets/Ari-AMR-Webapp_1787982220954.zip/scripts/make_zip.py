import os, zipfile

EXCLUDE_DIRS = {"node_modules", ".git", ".expo", ".turbo", "build", ".cache", "dist", ".local"}
EXCLUDE_EXT = {".tsbuildinfo"}
out = "/tmp/ARIbots.zip"
count = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            if any(f.endswith(e) for e in EXCLUDE_EXT):
                continue
            p = os.path.join(root, f)
            try:
                z.write(p, os.path.relpath(p, "."))
                count += 1
            except Exception as e:
                print("skip", p, e)
print("DONE files:", count)
print("size MB:", round(os.path.getsize(out) / 1024 / 1024, 2))
