"""Build the stewardship app as one self-contained HTML file.

The engine is pure computation over a versioned knowledge base and the case
store was always in memory, so the whole product runs in a browser with no
backend. This inlines the built JS, CSS and image assets into a single document
that can be hosted anywhere, including as a Claude Artifact whose content
security policy blocks every external host.
"""
import base64
import mimetypes
import os
import re
import subprocess
import sys

WEB = "artifacts/aribots-web"
DIST = f"{WEB}/dist/public"
OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/ari-stewardship.html"

env = dict(os.environ, PORT="20216", BASE_PATH="/", VITE_STANDALONE="1")
print("building...")
result = subprocess.run(
    ["pnpm", "--filter", "@workspace/aribots-web", "run", "build"],
    env=env, capture_output=True, text=True,
)
if result.returncode != 0:
    print(result.stdout[-4000:])
    print(result.stderr[-4000:])
    raise SystemExit("build failed")

html = open(f"{DIST}/index.html", encoding="utf-8").read()


def asset_data_uri(rel_path: str) -> str:
    path = os.path.join(DIST, rel_path.lstrip("/"))
    mime = mimetypes.guess_type(path)[0] or "application/octet-stream"
    with open(path, "rb") as fh:
        return f"data:{mime};base64,{base64.b64encode(fh.read()).decode()}"


# Inline the stylesheet.
def inline_css(match: re.Match) -> str:
    href = match.group(1)
    # Google Fonts is the one external host an Artifact's CSP permits, so the
    # font stylesheet stays a link rather than being inlined.
    if href.startswith(("http:", "https:", "//")):
        return match.group(0)
    css = open(os.path.join(DIST, href.lstrip("/")), encoding="utf-8").read()
    # Rewrite any url(...) references inside the CSS to data URIs.
    def css_asset(m: re.Match) -> str:
        target = m.group(1).strip("\"'")
        if target.startswith(("data:", "http:", "https:")):
            return m.group(0)
        try:
            return f"url({asset_data_uri(target)})"
        except OSError:
            return m.group(0)
    css = re.sub(r"url\(([^)]+)\)", css_asset, css)
    return f"<style>\n{css}\n</style>"


html = re.sub(r'<link[^>]+rel="stylesheet"[^>]*href="([^"]+)"[^>]*>', inline_css, html)
html = re.sub(r'<link[^>]+href="([^"]+)"[^>]*rel="stylesheet"[^>]*>', inline_css, html)


# Inline the module script.
def inline_js(match: re.Match) -> str:
    src = match.group(1)
    js = open(os.path.join(DIST, src.lstrip("/")), encoding="utf-8").read()
    # Any remaining asset references become data URIs.
    for asset in sorted(set(re.findall(r'"(/assets/[^"]+)"', js)), key=len, reverse=True):
        try:
            js = js.replace(f'"{asset}"', f'"{asset_data_uri(asset)}"')
        except OSError:
            pass
    return f"<script type=\"module\">\n{js}\n</script>"


html = re.sub(r'<script[^>]+type="module"[^>]+src="([^"]+)"[^>]*></script>', inline_js, html)

# Favicons become data URIs; the artifact host serves no sibling files.
def inline_icon(match: re.Match) -> str:
    tag, href = match.group(0), match.group(1)
    if href.startswith("data:"):
        return tag
    try:
        return tag.replace(href, asset_data_uri(href))
    except OSError:
        return ""


html = re.sub(r'<link[^>]+rel="(?:icon|apple-touch-icon)"[^>]*href="([^"]+)"[^>]*>', inline_icon, html)

leftover = re.findall(r'(?:src|href)="(/assets/[^"]+|/[\w.-]+\.(?:png|jpg|svg|ico))"', html)
if leftover:
    print("WARNING: uninlined references remain:", leftover[:5])

# Artifact mode emits page content only: the host supplies the document
# skeleton, so a second <html>/<head>/<body> would nest documents.
if os.environ.get("ARTIFACT_MODE") == "1":
    head = re.search(r"<head[^>]*>(.*?)</head>", html, re.S)
    body = re.search(r"<body[^>]*>(.*?)</body>", html, re.S)
    if not head or not body:
        raise SystemExit("could not split the document")
    html = head.group(1).strip() + "\n" + body.group(1).strip() + "\n"

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write(html)

print(f"wrote {OUT}  ({os.path.getsize(OUT) / 1024 / 1024:.2f} MB)")
